// import MathJax from 'better-react-mathjax/MathJax'
import React, { useEffect, useState } from 'react'

export const IIREquation = ({ filterCoefficients }) => {
  const [filterEquation, setFilterEquation] = useState('');

  const constructFilterEquationString = (filterCoefficients) => {
    console.log("computed num:", filterCoefficients.num);
    if (filterCoefficients.num.length === 0 && filterCoefficients.den.length === 0) return "y[n] = x[n]";
    let output = "y[n] = ";
    for (let i = 0; i < filterCoefficients.num.length; i++) {
      if (filterCoefficients.num[i] != 0) {
        if (i === 0) output += (Number(filterCoefficients.num[i]).toFixed(3) + "x[n]");
        else output += (Number(filterCoefficients.num[i]) < 0 ? " - " : " + ") +
          (Number(filterCoefficients.num[i]) == 1 ? "" : String(Math.abs(Number(filterCoefficients.num[i])).toFixed(5))) +
          "x[n-" + String(i) + "]";
      }
    }
    for (let i = 1; i < filterCoefficients.den.length; i++) {
      if (filterCoefficients.den[i] != 0) {
        output += (Number(filterCoefficients.den[i]) > 0 ? " - " : " + ") +
          (Number(filterCoefficients.den[i]) == 1 ? "" : String(Math.abs(Number(filterCoefficients.den[i])).toFixed(5))) +
          "y[n-" + String(i) + "]";
      }
    }
    return output;
  }

  useEffect(() => {
      if(filterCoefficients) setFilterEquation(() => constructFilterEquationString(filterCoefficients));
  }, [filterCoefficients]);

  return (
    <div className="overflow-x-scroll bg-gray-50 p-2 my-5 mx-2 rounded-2xl shadow-md" style={{ height: '168px', width: '530px'}}>
      <div className="p-4">
        <div className="font-bold">
          Filter equation:
        </div>
        {filterEquation ? filterEquation : "Empty"}
      </div>
    </div >
  )
}
