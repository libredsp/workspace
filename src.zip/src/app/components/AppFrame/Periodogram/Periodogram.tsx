import React, { useEffect, useState } from 'react'
import { Plot } from '../Common/Plot'
import { Panel } from './Panel';
import { ZeroPad } from '../../core';
import FFT from 'fft.js';

export const Periodogram = () => {
    const [data, setData] = useState([]);
    const [showInDbScale, setShowInDbScale] = useState(true);
    const [magnitudeResponse, setMagnitudeResponse] = useState({
        xValues: Array.from({ length: 1024 }, (_, i) => i / 1024 * Math.PI),
        yValues: Array.from({ length: 1024 }, (_, i) => 0)
    });

    const findTheNextPowerOfTwoBiggerThanX = (x: number) => {
        let v = 1;
        while (v < x) {
            v = v * 2;
        }
        return v;
    }
    const computePeriodogram = () => {
        let FFTSize = findTheNextPowerOfTwoBiggerThanX(data.length);
        let res = {
            xValues: Array.from({ length: FFTSize / 2 }, (_, i) => i / FFTSize * 2 * Math.PI),
            yValues: new Array(FFTSize / 2)
        };

        const fft = new FFT(FFTSize);
        const spectrum = fft.createComplexArray();
        fft.realTransform(spectrum, ZeroPad(data, FFTSize));

        // Compute magnitude of the freq. response
        if (showInDbScale) {
            for (let i = 0; i < FFTSize / 2; i++) {
                res.yValues[i] = 10 * Math.log( (1 / FFTSize) * (Math.pow(spectrum[i * 2], 2) + Math.pow(spectrum[i * 2 + 1], 2)));
            }            
        } else {
            for (let i = 0; i < FFTSize / 2; i++) {
                res.yValues[i] = (1 / FFTSize) * (Math.pow(spectrum[i * 2], 2) + Math.pow(spectrum[i * 2 + 1], 2));
            }
        }
        setMagnitudeResponse(() => res);
    }

    useEffect(() => {
        if (data && data.length > 0)
            computePeriodogram();
    }, [data, showInDbScale]);

    return (
        <div className="flex flex-col flex-1 items-stretch">
            <div className="flex">
                <Panel
                    data={data} updateData={(e) => setData(e)}
                    showInDbScale={showInDbScale}
                    updateShowInDbScale={(e) => setShowInDbScale(e)}
                />
                <Plot
                    title="Magnitude"
                    x_axis_label="w (rad)"
                    y_axis_label="|H^2(jw)|"
                    dataToPlot={magnitudeResponse}
                    plotColor={"rgba(75, 192, 192, 1)"} />

            </div>
        </div>

    )
}
