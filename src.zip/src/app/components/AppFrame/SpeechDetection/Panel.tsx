import React, { useState } from 'react'
import Infobox from '../../ui/Infobox';
import { LogisticRegressionModel, parseModel } from '../../core/speech/logistic_regression';

type PanelProps = {
    model: LogisticRegressionModel | null;
    updateModel: (m: LogisticRegressionModel | null) => void;
};

export const Panel = ({ model, updateModel }: PanelProps) => {
    const [fileName, setFileName] = useState("");
    const [error, setError] = useState("");

    const handleModelFile = (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (evt) => {
            try {
                updateModel(parseModel(evt.target.result as string));
                setFileName(file.name);
                setError("");
            } catch (err) {
                updateModel(null);
                setFileName("");
                setError(err.message);
            }
        };
        reader.readAsText(file);
    };

    return (
        <div className="flex flex-col bg-gray-50 p-2 my-5 mx-2 rounded-2xl shadow-md" style={{ width: '515px' }}>
            <div className="flex justify-between mx-5 my-1 mt-8">
                <h2 className="font-bold">Speech detection</h2>
                <Infobox text="Load a logistic regression model (model.txt) trained with the freedsp CLI, then load a .wav file to mark the segments that contain speech." />
            </div>
            <div className="flex flex-col m-5">
                <div className="flex items-center">
                    <span className="pr-5">Model:</span>
                    <label className="cursor-pointer">
                        <input type="file" className="hidden" accept=".txt" onChange={handleModelFile} />
                        <div className="px-4 w-32 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-sm transition">
                            <span>Choose File</span>
                        </div>
                    </label>
                    <span className="mx-4 text-sm text-gray-600">{fileName}</span>
                </div>
                {model && <p className="mt-3 text-sm text-green-700">Model loaded ({model.weights.length} weights).</p>}
                {error && <p className="mt-3 text-sm text-red-600">{error}</p>}
            </div>
        </div>
    );
}